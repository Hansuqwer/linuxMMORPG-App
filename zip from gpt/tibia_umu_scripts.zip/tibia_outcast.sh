#!/usr/bin/env bash
echo 'Outcast OT (placeholder)'
