#!/usr/bin/env bash
echo 'NoxiousOT (placeholder)'
