# Private Servers Batch Scripts
This pack includes separate UMU launcher scripts per server for:
- MU Online (5)
- Conquer Online (5)
- Aion (5)
- RF Online (5)
- TERA (5)
- ArcheAge (2 -- widely used ones)

Edit each script's EXE path to your installed client, then:
  chmod +x <script>.sh
  ./<script>.sh
