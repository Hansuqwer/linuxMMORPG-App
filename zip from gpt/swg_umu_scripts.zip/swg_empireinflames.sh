#!/usr/bin/env bash
echo 'Empire in Flames (placeholder)'
