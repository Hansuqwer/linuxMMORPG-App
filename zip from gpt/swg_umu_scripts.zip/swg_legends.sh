#!/usr/bin/env bash
echo 'SWG Legends (placeholder)'
