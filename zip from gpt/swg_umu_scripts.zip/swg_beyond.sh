#!/usr/bin/env bash
echo 'SWG Beyond (placeholder)'
