#!/usr/bin/env bash
echo 'SWG Infinity (placeholder)'
