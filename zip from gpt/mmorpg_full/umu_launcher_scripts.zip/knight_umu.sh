#!/usr/bin/env bash
echo "Knight Online UMU launcher (placeholder)"
