#!/usr/bin/env bash
echo "Silkroad Online UMU launcher (placeholder)"
