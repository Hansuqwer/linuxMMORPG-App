#!/usr/bin/env bash
echo "Generic UMU launcher (placeholder)"
