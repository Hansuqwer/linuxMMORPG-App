#!/usr/bin/env bash
echo "Perfect World UMU launcher (placeholder)"
