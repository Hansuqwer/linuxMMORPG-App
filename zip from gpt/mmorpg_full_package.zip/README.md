# MMORPG Full Package
This contains placeholder logos and basic UMU scripts.
