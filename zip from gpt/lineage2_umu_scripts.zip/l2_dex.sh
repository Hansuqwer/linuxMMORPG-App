#!/usr/bin/env bash
echo 'L2Dex launcher (real script should be here)'
