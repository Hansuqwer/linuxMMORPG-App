#!/usr/bin/env bash
echo 'L2 ElmoreLab launcher (real script should be here)'
