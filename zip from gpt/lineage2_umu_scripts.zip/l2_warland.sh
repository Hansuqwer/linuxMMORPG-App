#!/usr/bin/env bash
echo 'L2Warland launcher (real script should be here)'
