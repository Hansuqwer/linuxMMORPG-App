#!/usr/bin/env bash
echo 'E-Global launcher (real script should be here)'
