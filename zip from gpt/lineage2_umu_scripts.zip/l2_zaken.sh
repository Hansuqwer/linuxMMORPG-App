#!/usr/bin/env bash
echo 'Zaken launcher (real script should be here)'
