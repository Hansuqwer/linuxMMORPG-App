#!/usr/bin/env bash
echo 'FFXI HorizonXI (placeholder)'
