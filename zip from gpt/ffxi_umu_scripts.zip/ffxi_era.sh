#!/usr/bin/env bash
echo 'FFXI FFEra (placeholder)'
