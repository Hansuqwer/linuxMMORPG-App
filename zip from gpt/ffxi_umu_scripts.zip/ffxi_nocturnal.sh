#!/usr/bin/env bash
echo 'FFXI Nocturnal Souls (placeholder)'
