#!/usr/bin/env bash
echo 'FFXI CatsEyeXI (placeholder)'
