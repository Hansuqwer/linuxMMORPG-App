#!/usr/bin/env bash
echo 'FFXI EdenXI (placeholder)'
