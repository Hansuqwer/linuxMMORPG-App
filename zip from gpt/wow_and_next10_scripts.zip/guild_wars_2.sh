#!/usr/bin/env bash
set -euo pipefail
# Guild Wars 2 (official) via UMU/Proton
PREFIX="$HOME/Games/umu/gw2/default"
EXE="$HOME/Games/GuildWars2/Gw2-64.exe"
WINETRICKS="corefonts"
mkdir -p "$PREFIX"
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "" || true
# GW2 runs well under Proton; winetricks often minimal
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "$EXE"
