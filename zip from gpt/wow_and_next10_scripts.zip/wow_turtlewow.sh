#!/usr/bin/env bash
set -euo pipefail
# WoW Turtle WoW (Vanilla+) via UMU
# NOTE: Provide your own client files/launcher.
PREFIX="$HOME/Games/umu/wow/turtlewow"
EXE="$HOME/Games/WoW/TurtleWoW/WoW.exe"
WINETRICKS="d3dx9 vcrun2008 corefonts"
mkdir -p "$PREFIX"
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "" || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run winetricks -q $WINETRICKS || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "$EXE"
