#!/usr/bin/env bash
set -euo pipefail
# ArcheAge (private) via UMU
PREFIX="$HOME/Games/umu/archeage/default"
EXE="$HOME/Games/ArcheAge/ArcheAgeLauncher.exe"  # or AA.bin from custom packs
WINETRICKS="d3dx9 vcrun2010 vcrun2015 corefonts"
mkdir -p "$PREFIX"
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "" || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run winetricks -q $WINETRICKS || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "$EXE"
