#!/usr/bin/env bash
set -euo pipefail
# WoW ChromieCraft (WotLK) via UMU
PREFIX="$HOME/Games/umu/wow/chromiecraft"
EXE="$HOME/Games/WoW/ChromieCraft/Wow.exe"
WINETRICKS="d3dx9 vcrun2008 corefonts"
mkdir -p "$PREFIX"
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "" || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run winetricks -q $WINETRICKS || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "$EXE"
