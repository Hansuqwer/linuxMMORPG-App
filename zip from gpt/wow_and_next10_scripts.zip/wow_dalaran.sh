#!/usr/bin/env bash
set -euo pipefail
# WoW Dalaran-WoW (WotLK) via UMU
PREFIX="$HOME/Games/umu/wow/dalaran"
EXE="$HOME/Games/WoW/Dalaran/Wow.exe"
WINETRICKS="d3dx9 vcrun2008 corefonts"
mkdir -p "$PREFIX"
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "" || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run winetricks -q $WINETRICKS || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "$EXE"
