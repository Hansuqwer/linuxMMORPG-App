#!/usr/bin/env bash
set -euo pipefail
# RF Online (generic/private) via UMU
PREFIX="$HOME/Games/umu/rfonline/default"
EXE="$HOME/Games/RFOnline/rfonline.bin"   # or RF_Online.exe / launcher.exe depending on client
WINETRICKS="d3dx9 vcrun2008 corefonts"
mkdir -p "$PREFIX"
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "" || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run winetricks -q $WINETRICKS || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "$EXE"
