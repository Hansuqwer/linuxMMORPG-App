#!/usr/bin/env bash
set -euo pipefail
# Conquer Online (generic/private) via UMU
PREFIX="$HOME/Games/umu/conquer/default"
EXE="$HOME/Games/Conquer/Conquer.exe"   # or play.exe, autopatch.exe
WINETRICKS="d3dx9 vcrun2008 corefonts"
mkdir -p "$PREFIX"
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "" || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run winetricks -q $WINETRICKS || true
WINEPREFIX="$PREFIX" PROTONPATH="GE-Proton" umu-run "$EXE"
