# WoW + Next 10 MMORPG UMU Scripts
Includes WoW (5 servers) and next 10 games from your list (new coverage).
Edit EXE paths to your installed clients, make scripts executable, and run.
